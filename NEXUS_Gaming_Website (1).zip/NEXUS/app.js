const games = [
["Shell Shockers","Action & FPS","🥚","CrazyGames","https://www.crazygames.com/game/shellshockers","FPS"],
["Smash Karts","Action & FPS","🏎️","CrazyGames","https://www.crazygames.com/game/smash-karts","Battle"],
["Krunker.io","Action & FPS","🎯","Krunker","https://krunker.io/","FPS"],
["Venge.io","Action & FPS","🔫","Venge","https://venge.io/","Shooter"],
["Deadshot.io","Action & FPS","🎮","Deadshot","https://deadshot.io/","FPS"],
["BuildNow GG","Action & FPS","🧱","CrazyGames","https://www.crazygames.com/game/buildnow-gg","Building"],
["Bullet Force","Action & FPS","💥","CrazyGames","https://www.crazygames.com/game/bullet-force-multiplayer","FPS"],
["Narrow.One","Action & FPS","🏹","CrazyGames","https://www.crazygames.com/game/narrow-one","Action"],
["Miniblox.io","Action & FPS","🧊","Miniblox","https://miniblox.io/","Sandbox"],
["Combat Online","Action & FPS","🪖","CrazyGames","https://www.crazygames.com/game/combat-online","FPS"],
["Pixel Warfare","Action & FPS","🟪","CrazyGames","https://www.crazygames.com/game/pixel-warfare","FPS"],
["Stabfish.io","Action & FPS","🦈","Stabfish","https://stabfish.io/","Action"],
["EvoWars.io","Action & FPS","⚔️","EvoWars","https://evowars.io/","Action"],
["Merc Zone","Action & FPS","🛡️","CrazyGames","https://www.crazygames.com/game/merc-zone","FPS"],
["Funny Shooter 2","Action & FPS","👾","CrazyGames","https://www.crazygames.com/game/funny-shooter-2","Action"],
["Blockpost","Action & FPS","🧱","CrazyGames","https://www.crazygames.com/game/blockpost","FPS"],
["Masked Forces","Action & FPS","🥷","CrazyGames","https://www.crazygames.com/game/masked-forces","Action"],
["Super MX - The Champion","Action & FPS","🏍️","CrazyGames","https://www.crazygames.com/game/super-mx-the-champion","Racing"],
["Air Wars 3","Action & FPS","✈️","CrazyGames","https://www.crazygames.com/game/air-wars-3","Action"],
["Combat Reloaded","Action & FPS","🎖️","CrazyGames","https://www.crazygames.com/game/combat-reloaded","FPS"],
["Agar.io","IO & Multiplayer","🔵","Miniclip","https://agar.io/","IO"],
["Slither.io","IO & Multiplayer","🐍","Lowtech","https://slither.io/","IO"],
["Paper.io 2","IO & Multiplayer","🟨","Voodoo","https://paper-io.com/","IO"],
["Wormate.io","IO & Multiplayer","🐛","Wormate","https://wormate.io/","IO"],
["ZombsRoyale.io","IO & Multiplayer","🧟","Endix","https://zombsroyale.io/","Battle Royale"],
["Bloxd.io","IO & Multiplayer","🧊","CrazyGames","https://www.crazygames.com/game/bloxd-io","Sandbox"],
["Skribbl.io","IO & Multiplayer","✏️","Skribbl","https://skribbl.io/","Party"],
["Gartic Phone","IO & Multiplayer","🎨","Onrizon","https://garticphone.com/","Party"],
["Diep.io","IO & Multiplayer","🔺","Matheus","https://diep.io/","IO"],
["Defly.io","IO & Multiplayer","🚁","Defly","https://defly.io/","IO"],
["Hole.io","IO & Multiplayer","⚫","CrazyGames","https://www.crazygames.com/game/hole-io","Arcade"],
["Brutal.io","IO & Multiplayer","🔩","Brutal","https://brutal.io/","IO"],
["Splix.io","IO & Multiplayer","🟩","Splix","https://splix.io/","IO"],
["Moomoo.io","IO & Multiplayer","🌲","Moomoo","https://moomoo.io/","Survival"],
["Wormax.io","IO & Multiplayer","🐉","Wormax","https://wormax.io/","IO"],
["Gulper.io","IO & Multiplayer","🪱","Gulper","https://gulper.io/","IO"],
["Narwhale.io","IO & Multiplayer","🐋","Narwhale","https://narwhale.io/","IO"],
["Kombat.io","IO & Multiplayer","🥊","CrazyGames","https://www.crazygames.com/game/kombat-io","Action"],
["Tombstone.io","IO & Multiplayer","🤠","Tombstone","https://tombstone.io/","Action"],
["Paper.io Original","IO & Multiplayer","📐","Paper","https://paper-io.com/","IO"],
["Moto X3M","Racing & Driving","🏍️","CrazyGames","https://www.crazygames.com/game/moto-x3m","Stunts"],
["Drive Mad","Racing & Driving","🚙","CrazyGames","https://www.crazygames.com/game/drive-mad","Driving"],
["Madalin Stunt Cars 2","Racing & Driving","🏎️","CrazyGames","https://www.crazygames.com/game/madalin-stunt-cars-2","Stunts"],
["Poly Track","Racing & Driving","🏁","CrazyGames","https://www.crazygames.com/game/poly-track","Racing"],
["Super Star Car","Racing & Driving","🏎️","CrazyGames","https://www.crazygames.com/game/super-star-car","Racing"],
["Desktop Racing 2","Racing & Driving","🚗","CrazyGames","https://www.crazygames.com/game/desktop-racing-2","Racing"],
["Moto X3M Spooky Land","Racing & Driving","🎃","CrazyGames","https://www.crazygames.com/game/moto-x3m-spooky-land","Stunts"],
["Burnin Rubber 5 XS","Racing & Driving","🔥","CrazyGames","https://www.crazygames.com/game/burnin-rubber-5-xs","Combat"],
["Night City Racing","Racing & Driving","🌃","CrazyGames","https://www.crazygames.com/game/night-city-racing","Racing"],
["Grand Truck Simulator","Racing & Driving","🚚","CrazyGames","https://www.crazygames.com/game/grand-truck-simulator","Simulation"],
["Stunt Car Challenge 3","Racing & Driving","🚘","CrazyGames","https://www.crazygames.com/game/stunt-car-challenge-3","Stunts"],
["Extreme Car Driving Simulator","Racing & Driving","🚕","CrazyGames","https://www.crazygames.com/game/extreme-car-driving-simulator","Simulation"],
["MR RACER","Racing & Driving","💨","CrazyGames","https://www.crazygames.com/game/mr-racer","Racing"],
["Top Speed Racing 3D","Racing & Driving","⚡","CrazyGames","https://www.crazygames.com/game/top-speed-racing-3D","Racing"],
["Cyber Cars Punk Racing","Racing & Driving","🤖","CrazyGames","https://www.crazygames.com/game/cyber-cars-punk-racing","Racing"],
["Parking Fury 3D","Racing & Driving","🅿️","CrazyGames","https://www.crazygames.com/game/parking-fury-3d","Driving"],
["Parking Fury","Racing & Driving","🚙","Coolmath","https://www.coolmathgames.com/0-parking-fury","Driving"],
["Kart Race 3D","Racing & Driving","🏎️","CrazyGames","https://www.crazygames.com/game/kart-race-3d","Racing"],
["Highway Racer","Racing & Driving","🛣️","CrazyGames","https://www.crazygames.com/game/highway-racer","Racing"],
["Trial Bike Epic Stunts","Racing & Driving","🚵","CrazyGames","https://www.crazygames.com/game/trial-bike-epic-stunts","Stunts"],
["A Small World Cup","Sports & Casual","⚽","CrazyGames","https://www.crazygames.com/game/a-small-world-cup","Football"],
["Soccer Random","Sports & Casual","🥅","CrazyGames","https://www.crazygames.com/game/soccer-random","Football"],
["Basket Random","Sports & Casual","🏀","CrazyGames","https://www.crazygames.com/game/basket-random","Basketball"],
["Boxing Random","Sports & Casual","🥊","CrazyGames","https://www.crazygames.com/game/boxing-random","Boxing"],
["8 Ball Pool","Sports & Casual","🎱","CrazyGames","https://www.crazygames.com/game/8-ball-pool","Pool"],
["Basketball Legends 2020","Sports & Casual","🏀","CrazyGames","https://www.crazygames.com/game/basketball-legends-2020","Basketball"],
["Penalty Shooters 2","Sports & Casual","🥅","CrazyGames","https://www.crazygames.com/game/penalty-shooters-2","Football"],
["Pool Club","Sports & Casual","🎱","CrazyGames","https://www.crazygames.com/game/pool-club","Pool"],
["Mini Golf Master","Sports & Casual","⛳","CrazyGames","https://www.crazygames.com/game/mini-golf-master","Golf"],
["Table Tennis World Tour","Sports & Casual","🏓","CrazyGames","https://www.crazygames.com/game/table-tennis-world-tour","Tennis"],
["Football Legends","Sports & Casual","⚽","CrazyGames","https://www.crazygames.com/game/football-legends","Football"],
["Basket Champs","Sports & Casual","🏀","CrazyGames","https://www.crazygames.com/game/basket-champs","Basketball"],
["Bowling Stars","Sports & Casual","🎳","CrazyGames","https://www.crazygames.com/game/bowling-stars","Bowling"],
["Dunkers","Sports & Casual","🏀","CrazyGames","https://www.crazygames.com/game/dunkers","Basketball"],
["Archery World Tour","Sports & Casual","🏹","CrazyGames","https://www.crazygames.com/game/archery-world-tour","Archery"],
["Golf Orbit","Sports & Casual","🌌","CrazyGames","https://www.crazygames.com/game/golf-orbit","Golf"],
["Billiards 8 Ball","Sports & Casual","🎱","CrazyGames","https://www.crazygames.com/game/billiards-8-ball","Pool"],
["Soccer Legends","Sports & Casual","⚽","CrazyGames","https://www.crazygames.com/game/soccer-legends","Football"],
["Ski Jump","Sports & Casual","⛷️","CrazyGames","https://www.crazygames.com/game/ski-jump","Winter"],
["Tennis Masters","Sports & Casual","🎾","CrazyGames","https://www.crazygames.com/game/tennis-masters","Tennis"],
["Paper Minecraft","Puzzle & Strategy","⛏️","CrazyGames","https://www.crazygames.com/game/paper-minecraft","Sandbox"],
["Geometry Dash Lite","Puzzle & Strategy","🔷","CrazyGames","https://www.crazygames.com/game/geometry-dash","Rhythm"],
["Run 3","Puzzle & Strategy","🚀","Coolmath","https://www.coolmathgames.com/0-run-3","Platformer"],
["Chess Online","Puzzle & Strategy","♟️","Coolmath","https://www.coolmathgames.com/0-chess","Strategy"],
["Snake","Puzzle & Strategy","🐍","Coolmath","https://www.coolmathgames.com/0-cool-snake","Arcade"],
["Fireboy and Watergirl","Puzzle & Strategy","🔥","CrazyGames","https://www.crazygames.com/game/fireboy-and-watergirl-in-the-forest-temple","Puzzle"],
["Vex 4","Puzzle & Strategy","🤸","CrazyGames","https://www.crazygames.com/game/vex-4","Platformer"],
["Vex 5","Puzzle & Strategy","🧗","CrazyGames","https://www.crazygames.com/game/vex-5","Platformer"],
["Vex 6","Puzzle & Strategy","🌀","CrazyGames","https://www.crazygames.com/game/vex-6","Platformer"],
["Bob the Robber","Puzzle & Strategy","🕵️","CrazyGames","https://www.crazygames.com/game/bob-the-robber","Stealth"],
["Papa's Freezeria","Puzzle & Strategy","🍦","CrazyGames","https://www.crazygames.com/game/papas-freezeria","Simulation"],
["Papa's Pizzeria","Puzzle & Strategy","🍕","CrazyGames","https://www.crazygames.com/game/papas-pizzeria","Simulation"],
["Wheely","Puzzle & Strategy","🚗","CrazyGames","https://www.crazygames.com/game/wheely","Puzzle"],
["Snail Bob","Puzzle & Strategy","🐌","CrazyGames","https://www.crazygames.com/game/snail-bob","Puzzle"],
["Cut the Rope","Puzzle & Strategy","🍬","CrazyGames","https://www.crazygames.com/game/cut-the-rope","Puzzle"],
["Bloons Tower Defense","Puzzle & Strategy","🎈","CrazyGames","https://www.crazygames.com/game/bloons-tower-defense","Strategy"],
["Kingdom Rush","Puzzle & Strategy","🏰","CrazyGames","https://www.crazygames.com/game/kingdom-rush","Strategy"],
["World's Hardest Game","Puzzle & Strategy","🟥","Coolmath","https://www.coolmathgames.com/0-worlds-hardest-game","Arcade"],
["Tic Tac Toe","Puzzle & Strategy","❎","CrazyGames","https://www.crazygames.com/game/tic-tac-toe","Board"],
["Checkers Online","Puzzle & Strategy","⚫","CrazyGames","https://www.crazygames.com/game/checkers-online","Board"]
].map((g,i)=>({id:i+1,name:g[0],category:g[1],icon:g[2],provider:g[3],url:g[4],tag:g[5]}));
const palettes=["linear-gradient(135deg,#183e58,#392a78)","linear-gradient(135deg,#173a4b,#6b2f69)","linear-gradient(135deg,#172e4d,#285d71)","linear-gradient(135deg,#302044,#6a295e)","linear-gradient(135deg,#123d46,#254f8c)","linear-gradient(135deg,#33234e,#18566a)"];
let favorites = new Set(JSON.parse(localStorage.getItem("nexus-favorites")||"[]"));
let recent = JSON.parse(localStorage.getItem("nexus-recent")||"[]");
let xp = Number(localStorage.getItem("nexus-xp")||0);
let currentCategory="All", currentView="home", visibleCount=12, searchTerm="";
const $=id=>document.getElementById(id);
function persist(){localStorage.setItem("nexus-favorites",JSON.stringify([...favorites]));localStorage.setItem("nexus-recent",JSON.stringify(recent));localStorage.setItem("nexus-xp",String(xp));}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2500)}
function safe(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function level(){return Math.floor(xp/100)+1}
function card(g){return `<article class="game-card" data-id="${g.id}" tabindex="0" role="button" aria-label="Open ${safe(g.name)}"><div class="game-art" style="--art:${palettes[g.id%palettes.length]}"><span class="art-tag">${safe(g.tag.toUpperCase())}</span><button class="fav-btn ${favorites.has(g.id)?"favorited":""}" data-fav="${g.id}" aria-label="Toggle favorite">${favorites.has(g.id)?"♥":"♡"}</button><span class="game-symbol">${g.icon}</span></div><div class="game-info"><div class="game-title-line"><span class="game-title">${safe(g.name)}</span><span class="game-rating">★ ${(4.2+(g.id%8)/10).toFixed(1)}</span></div><div class="game-meta"><span>${safe(g.category)}</span><span>${safe(g.provider)}</span></div><div class="play-link"><span>▶ Play game</span><span>↗</span></div></div></article>`}
function filteredGames(){let list=games;if(currentView==="favorites")list=list.filter(g=>favorites.has(g.id));if(currentView==="recent")list=list.filter(g=>recent.includes(g.id)).sort((a,b)=>recent.indexOf(a.id)-recent.indexOf(b.id));if(currentCategory!=="All")list=list.filter(g=>g.category===currentCategory);if(searchTerm)list=list.filter(g=>(g.name+" "+g.category+" "+g.tag+" "+g.provider).toLowerCase().includes(searchTerm));return list}
function renderGrid(){let list=filteredGames();let grid=$("gameGrid");grid.innerHTML=list.slice(0,visibleCount).map(card).join("")||`<div class="empty"><strong>Nothing in this universe yet</strong>Try another category or search, or add games to your favorites.</div>`;$("loadMore").style.display=list.length>visibleCount?"block":"none";$("loadMore").textContent=`Load more games (${Math.max(0,list.length-visibleCount)} remaining) ↓`;wireCards()}
function wireCards(){document.querySelectorAll(".game-card").forEach(el=>{el.onclick=e=>{if(e.target.closest("[data-fav]"))return;openGame(Number(el.dataset.id))};el.onkeydown=e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openGame(Number(el.dataset.id))}}});document.querySelectorAll("[data-fav]").forEach(b=>b.onclick=e=>{e.stopPropagation();let id=Number(b.dataset.fav);favorites.has(id)?favorites.delete(id):favorites.add(id);persist();renderGrid();renderStats();if(currentView==="home")renderRecent();toast(favorites.has(id)?"Added to favorites":"Removed from favorites")})}
function renderRecent(){let list=recent.map(id=>games.find(g=>g.id===id)).filter(Boolean).slice(0,4);$("recentGames").innerHTML=list.map(card).join("")||`<div class="empty"><strong>Your adventure starts here</strong>Play a game and it will appear here.</div>`;wireCards()}
function renderStats(){$("statPlayed").textContent=recent.length;$("statFavorites").textContent=favorites.size;$("statXP").textContent=xp;$("statAchievements").textContent=(recent.length>0?1:0)+(recent.length>=10?1:0)+(favorites.size>=5?1:0);$("xpBar").style.width=(xp%100)+"%";$("xpCaption").textContent=`${xp%100} / 100 XP to level ${level()+1}`;$("sideLevel").textContent=`Level ${level()} · ${xp} XP`}
function renderLeaderboard(){let names=[["NovaByte","NX",4820],["PixelGhost","PG",4310],["CyberMia","CM",3970],["VoidWalker","VW",3520]];$("miniLeaderboard").innerHTML=names.map((n,i)=>`<div class="leader-row"><span class="rank">0${i+1}</span><span class="leader-avatar">${n[1]}</span><span class="leader-name">${n[0]}<small>${["Legendary","Elite","Rising star","Pro player"][i]}</small></span><span class="leader-xp">${n[2].toLocaleString()} XP</span></div>`).join("")}
function showView(view){currentView=view;currentCategory="All";visibleCount=12;document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));const titles={home:["Welcome back, <em>Player.</em>","Your next adventure is one click away."],games:["Game <em>Library.</em>","100 games. Five worlds. Infinite possibilities."],favorites:["Your <em>Favorites.</em>","Your personal collection of must-play games."],recent:["Recently <em>Played.</em>","Jump back into your latest adventures."],friends:["Your <em>Squad.</em>","Social features preview — connect with friends in a future backend release."],leaderboard:["Top <em>Players.</em>","Community leaderboard preview. Scores shown are demo data."],achievements:["Your <em>Achievements.</em>","Play, progress, and collect your milestones."],store:["Rewards <em>Store.</em>","Spend earned XP on profile flair — demo rewards."],settings:["Your <em>Settings.</em>","Make NEXUS feel like your own universe."]};$("pageTitle").innerHTML=(titles[view]||titles.home)[0];$("pageSubtitle").textContent=(titles[view]||titles.home)[1];$("continueSection").style.display=view==="home"?"block":"none";document.querySelectorAll(".section")[1].style.display=["friends","leaderboard","achievements","store","settings"].includes(view)?"none":"block";$("filters").style.display=view==="games"||view==="home"?"flex":"none";$("loadMore").style.display="block";if(["friends","leaderboard","achievements","store","settings"].includes(view)){if(view==="settings")openSettings();else if(view==="friends")openFriends();else if(view==="leaderboard")openLeaderboard();else if(view==="achievements")openAchievements();else openStore();return}renderGrid();if(view==="home")renderRecent();window.scrollTo({top:0,behavior:"smooth"})}
function openModal(content){$("modalContent").innerHTML=content;$("modalBackdrop").classList.add("open")}
function closeModal(){$("modalBackdrop").classList.remove("open")}
function openGame(id){const g=games.find(x=>x.id===id);if(!g)return;openModal(`<div class="eyebrow">${safe(g.category.toUpperCase())} · ${safe(g.provider.toUpperCase())}</div><h2>${safe(g.name)}</h2><div class="game-detail-art" style="background:${palettes[g.id%palettes.length]}">${g.icon}</div><p>${safe(g.name)} is part of the NEXUS curated game library. Your progress and recent-play list are stored locally in this browser.</p><div class="game-detail-actions"><button class="primary-btn" id="launchGame">▶ Play now ↗</button><button class="ghost-btn" id="detailFav">${favorites.has(id)?"♥ Remove favorite":"♡ Add favorite"}</button><button class="ghost-btn" id="shareGame">↗ Share</button></div><p class="form-note">Some game providers block embedding. NEXUS opens the official game in a new tab for best compatibility.</p>`);$("launchGame").onclick=()=>{recent=[id,...recent.filter(x=>x!==id)].slice(0,30);xp+=10;persist();renderRecent();renderStats();closeModal();window.open(g.url,"_blank","noopener,noreferrer");toast("Game launched · +10 XP")};$("detailFav").onclick=()=>{favorites.has(id)?favorites.delete(id):favorites.add(id);persist();renderGrid();renderStats();closeModal();toast(favorites.has(id)?"Added to favorites":"Removed from favorites")};$("shareGame").onclick=async()=>{try{await navigator.clipboard.writeText(g.url);toast("Game link copied")}catch{toast(g.url)}}}
function openSettings(){openModal(`<div class="eyebrow">PERSONALIZE YOUR EXPERIENCE</div><h2>Settings</h2><div class="settings-row"><span>Appearance theme</span><select id="themeSelect"><option value="dark">Deep Space (Default)</option><option value="amoled">AMOLED Black</option><option value="cyber">Cyberpunk</option><option value="sunset">Sunset</option></select></div><div class="settings-row"><span>Accent color</span><select id="accentSelect"><option value="cyan">Neon Cyan</option><option value="purple">Electric Purple</option><option value="pink">Gaming Pink</option><option value="green">Neon Green</option><option value="orange">Orange</option></select></div><div class="settings-row"><span>Animations</span><select id="motionSelect"><option value="on">On</option><option value="reduced">Reduced</option><option value="off">Off</option></select></div><div class="settings-row"><span>Card density</span><select id="densitySelect"><option value="comfortable">Comfortable</option><option value="compact">Compact</option></select></div><div class="settings-row"><span>Display name</span><input id="displayName" maxlength="20" value="${safe(localStorage.getItem("nexus-name")||"Guest Player")}"></div><button class="primary-btn" id="saveSettings">Save preferences</button><p class="form-note">Preferences are saved in this browser. Authentication and cloud sync require a configured backend.</p>`);$("themeSelect").value=localStorage.getItem("nexus-theme")||"dark";$("accentSelect").value=localStorage.getItem("nexus-accent")||"cyan";$("motionSelect").value=localStorage.getItem("nexus-motion")||"on";$("densitySelect").value=localStorage.getItem("nexus-density")||"comfortable";$("saveSettings").onclick=()=>{let theme=$("themeSelect").value,accent=$("accentSelect").value,motion=$("motionSelect").value,density=$("densitySelect").value,name=$("displayName").value.trim()||"Guest Player";localStorage.setItem("nexus-theme",theme);localStorage.setItem("nexus-accent",accent);localStorage.setItem("nexus-motion",motion);localStorage.setItem("nexus-density",density);localStorage.setItem("nexus-name",name);applySettings();$("sideUsername").textContent=name;$("pageTitle").innerHTML=`Welcome back, <em>${safe(name.split(" ")[0])}.</em>`;closeModal();toast("Preferences saved")}}
function applySettings(){const theme=localStorage.getItem("nexus-theme")||"dark",accent=localStorage.getItem("nexus-accent")||"cyan",motion=localStorage.getItem("nexus-motion")||"on",density=localStorage.getItem("nexus-density")||"comfortable";const root=document.documentElement;root.style.setProperty("--cyan",({cyan:"#00f0ff",purple:"#b026ff",pink:"#ff2e97",green:"#00ff88",orange:"#ff9b42"})[accent]);document.body.style.background=theme==="amoled"?"#000":theme==="cyber"?"radial-gradient(ellipse at 70% 0%,#281046 0,transparent 45%),#080610":theme==="sunset"?"radial-gradient(ellipse at 70% 0%,#55203c 0,transparent 45%),#15101b":"";document.body.style.animation=motion==="off"?"none":"";document.documentElement.style.scrollBehavior=motion==="off"?"auto":motion==="reduced"?"auto":"smooth";document.querySelectorAll(".game-art").forEach(x=>x.style.height=density==="compact"?"90px":"") }
function openAchievements(){openModal(`<div class="eyebrow">MILESTONES</div><h2>Achievements</h2>${[["🎯","First Adventure","Play your first game",recent.length>=1],["🔥","On a Roll","Play 7 different sessions",recent.length>=7],["🏆","Collector","Favorite 5 games",favorites.size>=5],["✦","XP Explorer","Earn 100 XP",xp>=100],["👑","Legendary","Reach level 10",level()>=10]].map(a=>`<div class="achievement"><div class="achievement-icon">${a[0]}</div><div><strong>${a[1]}</strong><small>${a[2]}</small></div><span class="earned">${a[3]?"UNLOCKED":"LOCKED"}</span></div>`).join("")}`)}
function openLeaderboard(){openModal(`<div class="eyebrow">COMMUNITY RANKINGS</div><h2>Leaderboard</h2><p>Demo leaderboard entries — online ranking requires a server.</p>${[["NovaByte","NX",4820],["PixelGhost","PG",4310],["CyberMia","CM",3970],["VoidWalker","VW",3520],["You","NX",xp]].sort((a,b)=>b[2]-a[2]).map((n,i)=>`<div class="leader-row"><span class="rank">0${i+1}</span><span class="leader-avatar">${n[1]}</span><span class="leader-name">${n[0]}<small>${n[0]==="You"?"Your local score":"NEXUS player"}</small></span><span class="leader-xp">${n[2].toLocaleString()} XP</span></div>`).join("")}`)}
function openFriends(){openModal(`<div class="eyebrow">SOCIAL HUB</div><h2>Friends & chat</h2><p>The social hub is ready for backend integration. Real friend requests, secure accounts, chat, presence, and voice calls need a server and user accounts.</p><div class="settings-row"><span>Online friends</span><strong>0</strong></div><div class="settings-row"><span>Pending requests</span><strong>0</strong></div><label>Find a friend by username</label><input id="friendSearch" placeholder="Enter username"><button class="primary-btn" id="friendSearchBtn">Search friends</button><p class="form-note">This frontend demo does not send data to a server.</p>`);$("friendSearchBtn").onclick=()=>toast("Friend search requires a connected backend")}
function openStore(){openModal(`<div class="eyebrow">COSMETICS · XP ONLY</div><h2>Rewards store</h2><p>Spend your earned XP on cosmetic items. Purchases are simulated and saved in this browser.</p>${[["🌌","Cosmic Profile Theme",100],["💠","Neon Avatar Frame",150],["✨","Star Chat Emote",50]].map((x,i)=>`<div class="achievement"><div class="achievement-icon">${x[0]}</div><div><strong>${x[1]}</strong><small>${x[2]} XP</small></div><button class="ghost-btn buy-item" data-item="${i}" data-cost="${x[2]}">Unlock</button></div>`).join("")}<p>Your balance: <strong>${xp} XP</strong></p>`);document.querySelectorAll(".buy-item").forEach(b=>b.onclick=()=>{let cost=Number(b.dataset.cost),owned=JSON.parse(localStorage.getItem("nexus-owned")||"[]"),id=Number(b.dataset.item);if(owned.includes(id)){toast("Already unlocked");return}if(xp<cost){toast("Not enough XP yet");return}xp-=cost;owned.push(id);localStorage.setItem("nexus-owned",JSON.stringify(owned));persist();renderStats();b.textContent="Unlocked";b.disabled=true;toast("Reward unlocked")})}
function openNotifications(){openModal(`<div class="eyebrow">INBOX</div><h2>Notifications</h2><div class="achievement"><div class="achievement-icon">✦</div><div><strong>Welcome to NEXUS</strong><small>Your gaming universe is ready to explore.</small></div></div><div class="achievement"><div class="achievement-icon">🎮</div><div><strong>100 games available</strong><small>Find a new favorite in the game library.</small></div></div><button class="primary-btn" id="markRead">Mark all as read</button>`);$("markRead").onclick=()=>{closeModal();toast("All notifications marked as read")}}
function showAbout(){openModal(`<div class="eyebrow">NEXUS GAMING PLATFORM</div><h2>Your universe. Your game.</h2><p>NEXUS is a responsive gaming hub concept with a curated 100-game catalog, live search, favorites, recently played, local XP progression, achievements, settings, and rewards.</p><p><strong>Prototype note:</strong> account authentication, online friends, real-time chat, cloud sync, and leaderboards need a properly configured backend. Game providers may block iframe embedding, so games open in a new tab.</p><button class="primary-btn" id="aboutExplore">Explore games ↗</button>`);$("aboutExplore").onclick=()=>{closeModal();showView("games")}}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("searchInput").addEventListener("input",e=>{searchTerm=e.target.value.trim().toLowerCase();if(currentView!=="games"&&currentView!=="home"&&currentView!=="favorites"&&currentView!=="recent")currentView="games";visibleCount=24;renderGrid();if(searchTerm)document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view==="games"))});
$("filters").addEventListener("click",e=>{let b=e.target.closest("[data-category]");if(!b)return;currentCategory=b.dataset.category;visibleCount=12;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderGrid()});
$("loadMore").onclick=()=>{visibleCount+=12;renderGrid()};
$("exploreBtn").onclick=()=>showView("games");$("quickPlay").onclick=()=>openGame(games[Math.floor(Math.random()*games.length)].id);$("featuredInfo").onclick=showAbout;$("aboutBtn").onclick=showAbout;
$("settingsBtn").onclick=()=>openSettings();$("sideSettings").onclick=()=>openSettings();$("profileBtn").onclick=()=>openSettings();$("promoBtn").onclick=()=>openStore();$("notificationsBtn").onclick=openNotifications;$("chatBtn").onclick=openFriends;
$("menuToggle").onclick=()=>$("sidebar").classList.toggle("open");
$("modalClose").onclick=closeModal;$("modalBackdrop").onclick=e=>{if(e.target===$("modalBackdrop"))closeModal()};document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){$("searchInput").focus();e.preventDefault()}});
$("sideUsername").textContent=localStorage.getItem("nexus-name")||"Guest Player";
applySettings();renderGrid();renderRecent();renderStats();renderLeaderboard();
