# Backend integration notes

The UI is intentionally static and stores demo preferences in browser localStorage. The supplied specification proposes Express, SQLite, Socket.IO and bcryptjs. Production implementation should add:

1. Express API with strict input validation, Helmet, rate limiting and CSRF protections.
2. SQLite migrations and parameterized queries.
3. Password hashing using bcryptjs/Argon2, secure HTTP-only cookies, email verification and password reset.
4. OAuth provider configuration and secrets in environment variables.
5. Socket.IO authentication/authorization for presence, messages and parties.
6. Server-authoritative XP, achievements, purchases and leaderboard scores.
7. Upload validation, size limits, malware scanning and non-public storage.
8. Tests, logging, backups, privacy/data deletion flows and deployment secrets management.

Do not expose secrets in frontend JavaScript or commit `.env` files.
