# NEXUS Ultimate Gaming Platform

A responsive static frontend prototype based on the supplied NEXUS master specification.

## Run it
- Easiest: open `index.html` in a modern browser.
- Recommended: run a local static server from this folder, e.g. `python -m http.server 8000`, then visit `http://localhost:8000`.

## Included
- 100-game catalog with search and category filters
- Game launch in a new tab (avoids provider iframe restrictions)
- Favorites and recently played saved in browser localStorage
- XP progression, achievements, demo leaderboard and XP rewards store
- Responsive layout, settings and theme/accent options
- Friends, notifications and profile UI previews

## Important
This is a frontend prototype, not a production-ready full-stack service. Real account authentication, password reset, email verification, OAuth, cloud persistence, secure sessions, real-time chat, online friend presence, voice chat and authoritative leaderboards require a backend, database, deployment configuration and security review. Do not collect real passwords with this static demo.

The catalog contains official third-party game URLs. Availability and embedding policies are controlled by each game provider.
